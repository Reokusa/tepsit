function changeColour(exColor)
{
	document.body.bgColor = exColor;
}

function colourCycle()
{
    if(i == color.length)
    {
        i = 0;
        document.body.bgColor = color[i];
    }
    else
    {
        i++;
        document.body.bgColor = color[i];
    }
}
var i = 0;  
var color = ['#FFFFFF', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#00FFFF', '#FF00FF'];